const plans = {
  both: {
    gym: [
      ["Agachamento livre ou goblet","3 séries • 8–12 repetições"],
      ["Flexão de braço ou supino","3 séries • 6–12 repetições"],
      ["Remada com halteres ou elástico","3 séries • 8–12 repetições"],
      ["Levantamento terra romeno leve","2 séries • 8–12 repetições"],
      ["Prancha","3 séries • 20–40 segundos"],
      ["Barra assistida ou puxada","2–3 séries • 6–12 repetições"]
    ],
    home: [
      ["Agachamento livre","3 séries • 8–15 repetições"],
      ["Flexão inclinada ou no chão","3 séries • 6–12 repetições"],
      ["Remada com elástico, se disponível","3 séries • 8–12 repetições"],
      ["Ponte de glúteos","3 séries • 10–15 repetições"],
      ["Prancha","3 séries • 20–40 segundos"],
      ["Elevação de panturrilha","2 séries • 12–20 repetições"]
    ]
  },
  gym: {
    gym: [
      ["Agachamento ou leg press","3 séries • 8–12 repetições"],
      ["Supino com halteres","3 séries • 8–12 repetições"],
      ["Puxada na polia","3 séries • 8–12 repetições"],
      ["Remada sentada","3 séries • 8–12 repetições"],
      ["Levantamento terra romeno","2 séries • 8–12 repetições"],
      ["Prancha","3 séries • 20–40 segundos"]
    ],
    home: [
      ["Agachamento livre","3 séries • 8–15 repetições"],
      ["Flexão inclinada","3 séries • 6–12 repetições"],
      ["Afundo com apoio","2 séries • 8–10 por lado"],
      ["Ponte de glúteos","3 séries • 10–15 repetições"],
      ["Elevação de panturrilha","2 séries • 12–20 repetições"],
      ["Prancha","3 séries • 20–40 segundos"]
    ]
  },
  calisthenics: {
    gym: [
      ["Barra assistida","3 séries • 5–8 repetições"],
      ["Flexão de braço","3 séries • 6–12 repetições"],
      ["Agachamento com peso corporal","3 séries • 10–15 repetições"],
      ["Remada invertida, se disponível","3 séries • 6–10 repetições"],
      ["Elevação de joelhos controlada","2 séries • 8–12 repetições"],
      ["Prancha","3 séries • 20–40 segundos"]
    ],
    home: [
      ["Flexão na parede ou inclinada","3 séries • 6–12 repetições"],
      ["Agachamento com peso corporal","3 séries • 10–15 repetições"],
      ["Afundo com apoio","2 séries • 8–10 por lado"],
      ["Ponte de glúteos","3 séries • 10–15 repetições"],
      ["Bird-dog","2 séries • 8 por lado"],
      ["Prancha","3 séries • 15–30 segundos"]
    ]
  }
};
const $ = id => document.getElementById(id);
function selectedPlan(){
  const mod = $("modality").value;
  const place = $("place").value;
  const key = place === "home" ? "home" : "gym";
  let items = plans[mod][key];
  if ($("level").value === "beginner") items = items.map(x => [x[0], x[1].replace("3 séries","2 séries").replace("2–3 séries","2 séries")]);
  return items;
}
function renderExercises(target, items){
  $(target).innerHTML = "";
  items.forEach((item,i)=>{
    const el = document.createElement("div");
    el.className = "card exercise";
    el.innerHTML = `<div class="number">${i+1}</div><div><strong></strong><small></small></div>`;
    el.querySelector("strong").textContent = item[0];
    el.querySelector("small").textContent = item[1];
    $(target).appendChild(el);
  });
}
function getCount(){return Number(localStorage.getItem("mtp_sessions") || 0)}
function updateCount(){$("sessionsCount").textContent=getCount();$("progressCount").textContent=getCount()}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===btn.dataset.page));
}));
$("generate").addEventListener("click",()=>renderExercises("workoutExercises",selectedPlan()));
$("finishWorkout").addEventListener("click",()=>{
  localStorage.setItem("mtp_sessions",String(getCount()+1)); updateCount();
  $("finishWorkout").textContent="Treino concluído ✓";
  setTimeout(()=>{$("finishWorkout").textContent="Marcar treino como concluído"},1500);
});
$("resetProgress").addEventListener("click",()=>{
  if(confirm("Quer mesmo zerar o histórico deste navegador?")){localStorage.removeItem("mtp_sessions");updateCount()}
});
renderExercises("homeExercises",plans.both.gym);
renderExercises("workoutExercises",selectedPlan());
updateCount();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js").catch(()=>{});
