const ex = (name, sets, reps, equipment='') => ({name, sets, reps, equipment});
const library = {
  full: {
    gym: [ex('Agachamento livre',3,'8–12 repetições'),ex('Supino com halteres',3,'8–12 repetições'),ex('Puxada na polia',3,'8–12 repetições'),ex('Remada sentada',3,'8–12 repetições'),ex('Levantamento terra romeno',2,'8–12 repetições'),ex('Prancha',3,'20–40 segundos')],
    home: [ex('Agachamento com peso corporal',3,'10–15 repetições'),ex('Flexão inclinada ou no chão',3,'6–12 repetições'),ex('Remada com elástico ou mochila leve',3,'8–12 repetições'),ex('Ponte de glúteos',3,'10–15 repetições'),ex('Elevação de panturrilha',2,'12–20 repetições'),ex('Bird-dog',2,'8–10 por lado')]
  },
  push: {
    gym: [ex('Supino reto com halteres ou barra',3,'8–12 repetições'),ex('Supino inclinado com halteres',3,'8–12 repetições'),ex('Desenvolvimento de ombros',3,'8–12 repetições'),ex('Elevação lateral',2,'12–15 repetições'),ex('Tríceps na polia',3,'10–15 repetições')],
    home: [ex('Flexão inclinada',3,'6–12 repetições'),ex('Flexão tradicional (ou versão inclinada)',3,'6–12 repetições'),ex('Flexão pike adaptada',2,'6–10 repetições'),ex('Flexão fechada adaptada',2,'6–12 repetições'),ex('Prancha com toque no ombro',2,'8–12 por lado')]
  },
  pull: {
    gym: [ex('Puxada alta na polia',3,'8–12 repetições'),ex('Remada baixa sentada',3,'8–12 repetições'),ex('Remada unilateral com halter',3,'8–12 por lado'),ex('Face pull na polia',2,'12–15 repetições'),ex('Rosca direta',3,'10–12 repetições'),ex('Rosca martelo',2,'10–12 repetições')],
    home: [ex('Barra fixa assistida ou negativa controlada',3,'3–8 repetições'),ex('Remada com mochila leve',3,'8–12 repetições'),ex('Remada com elástico',3,'10–15 repetições'),ex('Rosca com elástico',2,'10–15 repetições'),ex('Bird-dog',2,'8 por lado')]
  },
  legs: {
    gym: [ex('Agachamento livre ou goblet',3,'8–12 repetições'),ex('Leg press',3,'10–12 repetições'),ex('Levantamento terra romeno',3,'8–12 repetições'),ex('Cadeira flexora',2,'10–15 repetições'),ex('Elevação pélvica',3,'10–15 repetições'),ex('Panturrilha em pé',3,'12–20 repetições')],
    home: [ex('Agachamento com peso corporal',3,'10–15 repetições'),ex('Afundo com apoio',2,'8–10 por lado'),ex('Ponte de glúteos',3,'12–15 repetições'),ex('Bom dia sem peso',2,'10–15 repetições'),ex('Elevação de panturrilha',3,'12–20 repetições'),ex('Agachamento na cadeira',2,'8–12 repetições')]
  },
  upper: {
    gym: [ex('Supino com halteres',3,'8–12 repetições'),ex('Puxada alta',3,'8–12 repetições'),ex('Remada sentada',3,'8–12 repetições'),ex('Desenvolvimento de ombros',2,'8–12 repetições'),ex('Elevação lateral',2,'12–15 repetições'),ex('Rosca direta',2,'10–12 repetições'),ex('Tríceps na polia',2,'10–15 repetições')],
    home: [ex('Flexão inclinada',3,'6–12 repetições'),ex('Barra fixa assistida ou remada com elástico',3,'6–12 repetições'),ex('Remada com mochila leve',3,'8–12 repetições'),ex('Flexão pike adaptada',2,'6–10 repetições'),ex('Rosca com elástico',2,'10–15 repetições'),ex('Prancha',2,'20–40 segundos')]
  },
  lower: {
    gym: [ex('Agachamento ou leg press',3,'8–12 repetições'),ex('Levantamento terra romeno',3,'8–12 repetições'),ex('Cadeira extensora',2,'10–15 repetições'),ex('Cadeira flexora',2,'10–15 repetições'),ex('Elevação pélvica',3,'10–15 repetições'),ex('Panturrilha',3,'12–20 repetições')],
    home: [ex('Agachamento com peso corporal',3,'10–15 repetições'),ex('Afundo com apoio',2,'8–10 por lado'),ex('Ponte de glúteos',3,'12–15 repetições'),ex('Bom dia sem peso',2,'10–15 repetições'),ex('Elevação de panturrilha',3,'12–20 repetições'),ex('Bird-dog',2,'8 por lado')]
  }
};
const splitNames={full:'Corpo inteiro',push:'Empurrar',pull:'Puxar',legs:'Pernas e glúteos',upper:'Parte superior',lower:'Parte inferior'};
const meals=[
 {cat:'breakfast',icon:'🍳',title:'Ovos mexidos, pão e fruta',desc:'Ovos com pão e banana, mamão ou outra fruta.',tag:'Rápido'},
 {cat:'breakfast',icon:'🥣',title:'Aveia com banana',desc:'Aveia com leite ou iogurte, banana e canela.',tag:'Sem complicação'},
 {cat:'breakfast',icon:'🥪',title:'Sanduíche de queijo e ovo',desc:'Pão com ovo e queijo, acompanhado de uma fruta.',tag:'Salgado'},
 {cat:'breakfast',icon:'🥞',title:'Panqueca de banana e aveia',desc:'Banana amassada, ovo e aveia; sirva com iogurte se quiser.',tag:'Caseiro'},
 {cat:'breakfast',icon:'🥛',title:'Vitamina com aveia',desc:'Leite ou bebida adequada, banana e aveia; pode acompanhar pão.',tag:'Para levar'},
 {cat:'lunch',icon:'🍛',title:'Arroz, feijão e frango',desc:'Arroz, feijão, frango grelhado ou desfiado e legumes.',tag:'Clássico econômico'},
 {cat:'lunch',icon:'🍗',title:'Sobrecoxa com arroz e salada',desc:'Sobrecoxa assada ou cozida, arroz, feijão e salada.',tag:'Preparar em lote'},
 {cat:'lunch',icon:'🥩',title:'Carne moída com batata',desc:'Carne moída, batata cozida ou assada e legumes.',tag:'Uma panela'},
 {cat:'lunch',icon:'🐟',title:'Sardinha com arroz e feijão',desc:'Sardinha, arroz, feijão e tomate ou outro legume.',tag:'Alternativa acessível'},
 {cat:'lunch',icon:'🍝',title:'Macarrão com carne moída',desc:'Macarrão com molho de tomate e carne moída ou lentilha.',tag:'Fácil de fazer'},
 {cat:'lunch',icon:'🥚',title:'Arroz, feijão e omelete',desc:'Omelete com legumes, arroz e feijão.',tag:'Sem carne'},
 {cat:'lunch',icon:'🥔',title:'Frango com mandioca',desc:'Frango cozido ou assado, mandioca e vegetais.',tag:'Boa variedade'},
 {cat:'snack',icon:'🍌',title:'Banana com aveia',desc:'Banana com aveia; acrescente iogurte se desejar.',tag:'Pré-treino simples'},
 {cat:'snack',icon:'🥛',title:'Iogurte com fruta',desc:'Iogurte com fruta da estação e granola ou aveia.',tag:'Lanche rápido'},
 {cat:'snack',icon:'🥪',title:'Sanduíche de frango',desc:'Pão com frango desfiado e salada.',tag:'Pode preparar antes'},
 {cat:'snack',icon:'🧀',title:'Pão com queijo',desc:'Pão com queijo e uma fruta ou leite.',tag:'Prático'},
 {cat:'snack',icon:'🥜',title:'Fruta e amendoim',desc:'Uma fruta com pequena porção de amendoim, se não houver alergia.',tag:'Não precisa refrigerar'},
 {cat:'snack',icon:'🥤',title:'Vitamina de banana',desc:'Leite, banana e aveia batidos; adapte à sua fome.',tag:'Pós-treino opcional'},
 {cat:'dinner',icon:'🍲',title:'Repeteco do almoço',desc:'Arroz, feijão, uma proteína e legumes: simples e completo.',tag:'Econômico'},
 {cat:'dinner',icon:'🍳',title:'Omelete reforçada',desc:'Ovos com tomate, cebola e queijo, com pão ou batata.',tag:'Rápido'},
 {cat:'dinner',icon:'🌯',title:'Wrap de frango',desc:'Tortilha ou pão folha com frango, feijão e vegetais.',tag:'Para variar'},
 {cat:'dinner',icon:'🍝',title:'Macarrão com atum ou sardinha',desc:'Macarrão, peixe enlatado e molho de tomate.',tag:'Despensa'},
 {cat:'dinner',icon:'🥣',title:'Sopa com feijão e legumes',desc:'Sopa de legumes com feijão e ovo ou frango desfiado.',tag:'Confortável'},
 {cat:'dinner',icon:'🥔',title:'Batata recheada',desc:'Batata assada com frango desfiado, feijão ou queijo e salada.',tag:'Versátil'}
];
const catNames={breakfast:'Café da manhã',lunch:'Almoço',snack:'Lanche / pré ou pós-treino',dinner:'Jantar'};
const $=id=>document.getElementById(id);
function getCount(){return Number(localStorage.getItem('mtp_sessions')||0)}
function updateCount(){$('sessionsCount').textContent=getCount();$('progressCount').textContent=getCount()}
function videoUrl(name){return 'https://www.youtube.com/results?search_query='+encodeURIComponent(name+' execução correta exercício short')}
function renderExercises(target,items){
 const root=$(target);root.innerHTML='';
 items.forEach((item,i)=>{
  const card=document.createElement('article');card.className='card exercise-card';
  const top=document.createElement('div');top.className='exercise';
  const num=document.createElement('div');num.className='number';num.textContent=String(i+1);
  const info=document.createElement('div');info.className='exercise-info';
  const title=document.createElement('strong');title.textContent=item.name;
  const detail=document.createElement('small');detail.textContent=(item.sets+' séries • '+item.reps)+(item.equipment?' • '+item.equipment:'');
  info.append(title,detail);top.append(num,info);card.append(top);
  const link=document.createElement('a');link.className='video-link';link.href=videoUrl(item.name);link.textContent='▶ Buscar vídeo curto no YouTube';card.append(link);root.append(card);
 });
 $('exerciseCount').textContent=items.length;
}
function currentExercises(){
 const place=$('place').value==='home'?'home':'gym';const split=$('split').value;let items=[...library[split][place]];
 if($('modality').value==='calisthenics') items=items.filter(x=>/flexão|barra|agachamento|remada|prancha|ponte|afundo|bird-dog|panturrilha|pike|bom dia/i.test(x.name));
 if($('level').value==='beginner') items=items.map(x=>({...x,sets:Math.max(2,x.sets-1)}));
 return items;
}
function renderWorkout(){const items=currentExercises();$('workoutTitle').textContent=splitNames[$('split').value]+' • '+($('place').value==='home'?'Casa':'Academia');renderExercises('workoutExercises',items);$('todayTitle').textContent=splitNames[$('split').value];}
function renderMeals(){const selected=$('mealCategory').value;const root=$('mealList');root.innerHTML='';meals.filter(m=>selected==='all'||m.cat===selected).forEach(m=>{const card=document.createElement('article');card.className='card meal';const icon=document.createElement('div');icon.className='meal-icon';icon.textContent=m.icon;const content=document.createElement('div');const title=document.createElement('h3');title.textContent=m.title;const desc=document.createElement('p');desc.textContent=m.desc;const tag=document.createElement('span');tag.className='tag';tag.textContent=m.tag;const cat=document.createElement('div');cat.className='meal-category';cat.textContent=catNames[m.cat];content.append(cat,title,desc,tag);card.append(icon,content);root.append(card)})}
document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===btn.dataset.page))}));
$('generate').addEventListener('click',renderWorkout);['modality','place','split','level'].forEach(id=>$(id).addEventListener('change',renderWorkout));$('mealCategory').addEventListener('change',renderMeals);
$('finishWorkout').addEventListener('click',()=>{localStorage.setItem('mtp_sessions',String(getCount()+1));updateCount();$('finishWorkout').textContent='Treino concluído ✓';setTimeout(()=>$('finishWorkout').textContent='Marcar treino como concluído',1500)});
$('resetProgress').addEventListener('click',()=>{if(confirm('Quer mesmo zerar o histórico deste aparelho?')){localStorage.removeItem('mtp_sessions');updateCount()}});
renderWorkout();renderMeals();updateCount();
